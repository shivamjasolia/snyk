<html>

<head>
    <style>
        img {
            padding: 30px;
            display: block;
            margin-left: auto;
            margin-right: auto;
        }
    </style>
</head>

<body>
    <h1 style="text-align:center;"> Your Record Is Successfully Updated. </h1>
    <img src="https://www.randmcnally.com/images/img-protean/support-main/ODProMapUpdate3.jpg" height="400px">
    <script>
        setTimeout(myFunction, 2000);

        function myFunction() {
            window.location.href = "employeelist.php";
        }
    </script>
</body>

</html>