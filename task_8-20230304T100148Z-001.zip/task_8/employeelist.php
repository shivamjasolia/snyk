<?php
include "main_api.php";
if (!isset($_SESSION['id'])) {
    header("location:login.php");
}
$obj = new adminLogin();
$id = $_SESSION['id'];
?>
<html>

<head>
    <link rel="stylesheet" type="text/css" href="assets\css\employeelist.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/underscore.js/1.9.1/underscore-min.js">
    </script>
    <script src="assets\js\main.js"></script>
</head>

<body>
    <a style="float:left;margin:5px;" class="back">Back</a>
    <a class='logout'> Log-Out </a><br><br>
    <h2> View All Users Record List </h2>
    <form id="live_s" method="post">
        <div id="lsearch">
            <label for="search"> Employee Search :</label>
            <input type="search" class="search" id="search" name="search" >
            <br>
        </div>
    </form>
    <table>
        <tr>
            <th>No</th>
            <th>Employee.No</th>
            <th>Nama</th>
            <th>Designation</th>
            <th>Join Date</th>
            <th colspan="2">Action</th>
        </tr>
        <tbody id="response-data">

        </tbody>
    </table>

    <!-- <span style="cursor:pointer"><a style="float:right;" class="delete">Delete</a></span> -->
</body>

</html>