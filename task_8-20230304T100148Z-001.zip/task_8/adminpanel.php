<?php
include "main_api.php";
$obj = new adminLogin();
$name = $_SESSION['name'];
if (!isset($_SESSION['id'])) {
    header("Location:login.php");
}
?>
<!Doctype html>
<html>

<head>
    <link rel="stylesheet" type="text/css" href="assets\css\adminpanel.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
    <script src="assets\js\main.js"></script>
</head>

<body>
    <!-- navigation bar -->
    <ul class="navbar">
        <img id="logo" style="float:left;cursor:pointer" src="https://cdn.impactinit.com/resizenp/600x600/x@7c924f1572/smss53/smsimg28/pv1000/isignstockcontributors/iss_15187_06814.jpg" height="47.5px">
        <li><a class="reg_a">Create User</a></li>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        <li><a class="empl_a"> Employee List </a> </li>&nbsp;&nbsp;
        <!-- <li><a class="empatc_a">Attendance History</a><li> -->
        <li style="float:right;cursor:pointer"><a class="logout">Logout</a></li>
    </ul>
    <!-- welcome -->
    <h1 class='wel'>Welcome! Mr.<?php echo $name; ?></h1>
    <img class="logo" src="https://cdn.impactinit.com/resizenp/600x600/x@7c924f1572/smss53/smsimg28/pv1000/isignstockcontributors/iss_15187_06814.jpg">
    <p class="co">identixweb.Pvt.Ltd </p>
    <p class="co">&copy;2016-<?php echo date("Y") ?>.All rights reserved</p>
</body>

</html>