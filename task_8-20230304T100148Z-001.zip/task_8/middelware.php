<?php
include "main_api.php";
$obj = new adminLogin();
if(isset($_POST['type'])){
    call_user_func(array($obj, $_POST['type']));
}
?>
