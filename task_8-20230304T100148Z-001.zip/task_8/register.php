<?php
include "main_api.php";
if (!isset($_SESSION['id'])) {
    header("location:login.php");
}
$obj = new adminLogin();

?>
<!DOCTYPE html>
<html>

<head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="text/css" href="assets\css\register.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
    <script src="assets\js\main.js"></script>
</head>

<body>
    <a style="margin-top:20px;" class="back">Back</a>
    <form name="myForm" id="register" method="post" enctype="multipart/form-data">
        <div class="container">
            <img id="logo" style="cursor:pointer" src="https://cdn.impactinit.com/resizenp/600x600/x@7c924f1572/smss53/smsimg28/pv1000/isignstockcontributors/iss_15187_06814.jpg" height="100px">
            <!-- <hr> -->
            <h1 style="text-align:center;">Register</h1>
            <p style="text-align:center;">Please fill in this form to create an account.</p>
            <hr>
            <div>
                <span class="form-message"></span>
            </div>
            <!-- name -->
            <label for="name"><b>Name</b></label>
            <input type="text" name="name" id="name" value="">
            <span class="err" id="err_name"></span>
            <br><br><br>
            <!-- Email -->
            <label for="e_id"><b>Eemployee.No</b></label>
            <input type="text" name="e_id" id="e_id" value="">
            <span class="err" id="err_e_id"></span>
            <br><br><br>
            <!-- departmentid -->
            <label for="d_id"> <b> Designation : </b> </label>
            <select class="one" name="d_id" id="d_id">
                <option class="option" disabled hidden selected> -- Select Item -- </option>
                <?php
                $dep_id = $obj->designation();
                ?>
            </select>
            &nbsp;&nbsp;&nbsp;
            <br>
            <span class="err" id="err_d_id"></span>
            <hr>
            <button type="submit" name="submit" class="registerbtn" style="font-size : 17px;text-align:center">Register</button>
        </div>
    </form>
    <br><br>

</body>

</html>