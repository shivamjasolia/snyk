<?php 
class connection{
public $servername = "localhost";
        public $username = "root";
        public $password = "";
        public $database = "attendance_em";
        public $conn ;
        
        public function __construct(){
            $this->conn = new mysqli($this->servername,$this->username,$this->password,$this->database);
            if($this->conn->connect_error){
                echo "Connection Is Failed";
            }
            // else{
            //     echo "Connection Is Done";
            // }
        }
    }
?>