<?php
session_start();
include "conn.php";
class adminLogin extends connection
{
    // Response 
    private $error = array(
        "status" => 0,
        "message" => "Please Re-Submit Form"
    );
    // Employee Designation
    public function designation($des_id = 0)
    {
        $select = "SELECT d_id,title FROM designation";
        $query = $this->conn->query($select);
        // return $query;
        foreach ($query as $row) {
            $d_id = $row['d_id'];
            $d_title = $row['title'];
?>
            <option class="option" <?php echo $des_id == $d_id ? "selected" : ""; ?> value="<?php echo $d_id; ?>"><?php echo $d_title; ?></option>
            <?php
        }
    }
    //Employee Register
    public function insertVal()
    {
        $name =  $this->conn->real_escape_string($_POST['name']);
        $d_id = $_POST['d_id'];
        $e_id = $_POST['e_id'];
        if ($name == null) {
            $this->error['status'] = 0;
            $this->error['message'] = "Please Enter Name";
        } else if ($d_id == null) {
            $this->error['status'] = 0;
            $this->error['message'] = "Please Enter Employee.No ";
        } else if ($e_id == null) {
            $this->error['status'] = 0;
            $this->error['message'] = "Please Enter Designation";
        } else {
            $this->error['status'] = 1;
        }
        if ($this->error['status'] == 1) {
            $check = "SELECT * FROM employee_register WHERE e_id = '$e_id'";
            $r = $this->conn->query($check);
            if ($r->num_rows == 1) {
                $this->error['status'] = 0;
                $this->error['message'] = 'Sorry! This Employee ID Already Exists';
            } else {
                $insert = "INSERT INTO employee_register(e_id,name,d_id) VALUES ('$e_id','$name','$d_id')";
                $query = $this->conn->query($insert);
                if ($query == TRUE) {
                    $this->error['status'] = 1;
                    $this->error['message'] = "Data Insert Successfull";
                }
            }
        } else {
            $this->error['status'] = 0;
            $this->error['message'] = "Please Fill All Details In Form";
        }
        echo json_encode($this->error);
    }
    //Login Admin
    public function loginChk()
    {
        $email = $_POST['email'];
        $pass = base64_encode($_POST['pass']);
        if ($email == null) {
            $this->error['message'] = "Please Enter Email";
        } else if ($pass == null) {
            $this->error['message'] = "Please Enter Your Password";
        } else {
            $this->error['status'] = 1;
        }
        if ($this->error['status'] == 1) {
            $select = "SELECT id,name,email,password FROM `admin` WHERE email = '$email' AND password = '$pass'";
            $result = $this->conn->query($select);
            if ($result->num_rows > 0) {
                foreach ($result as $row) {
                    $_SESSION['id'] = $row['id'];
                    $_SESSION['name'] = $row['name'];
                }
                $this->error['status'] = 1;
                $this->error['message'] = "Login Successfull";
            } else {
                $this->error['status'] = 0;
                $this->error['message'] = "Please Insert valid Details";
            }
        }
        echo json_encode($this->error);
    }
    //All Employee-list
    public function showData()
    {
        $counter = 1;
        $show = "SELECT e.em_id,e.name,e.e_id,e.d_id,d.title,e.created_on
            FROM `employee_register` AS e
            INNER JOIN `designation` AS d
            ON e.d_id = d.d_id";
        $result = $this->conn->query($show);
        if ($result->num_rows > 0) {
            foreach ($result as $row) {
                $emid = $row['em_id'];
            ?>
                <tr>
                    <td><?php echo $counter++; ?> </td>
                    <td><?php echo $row['e_id']; ?> </td>
                    <td><?php echo stripslashes($row['name']); ?></td>
                    <td><?php echo $row['title']; ?></td>
                    <td><?php echo date("d-M-Y", strtotime($row['created_on'])); ?></td>
                    <td><a id="edit" href="updatepage.php?id=<?php echo base64_encode($emid); ?>">Update</a></td>
                    <td><a id="history" class="history" href="historypage.php?e_id=<?php echo base64_encode($emid); ?>">History</a></td>
                </tr>
            <?php
            }
            $this->error['status'] = 1;
        }
    }
    // Update user ID
    public function updateEmp()
    {
        $em_id =  base64_decode($_GET['id']);
        $select = "SELECT * FROM employee_register as e
        INNER JOIN designation as d
        ON e.d_id = d.d_id
        WHERE em_id = $em_id";
        $query = $this->conn->query($select);
        $row = $query->fetch_assoc();
        return $row;
    }
    public function getName()
    {
        $e_id = $_SESSION['e_id'];
        $select = "SELECT * FROM employee_register
        WHERE em_id = '$e_id' LIMIT 1";
        $query = $this->conn->query($select);
        $rf = $query->fetch_assoc();
        return $rf;
    }
    function timeConvert($sum)
    {
        $hours = intval($sum / 3600);
        $second_remain = ($sum - ($hours * 3600));
        $minutes = intval($second_remain / 60);
        $seconds = ($second_remain - ($minutes * 60));
        $time_c = ($hours <= 9 ? "0" : "") . $hours . "h:" . ($minutes <= 9 ? "0" : "") . $minutes . "m:" . ($seconds <= 9 ? "0" : "") . $seconds . "s";
        return $time_c;
    }
    // User History
    public function historyAttandance()
    {
        $counter = 1;
        $sum_w = 0;
        $sum_b = 0;
        $sum_t = 0;
        $em_id = $_SESSION['e_id'];
        $s_date = date("Y-m-d", strtotime($_POST['s_date']));
        $e_date = date("Y-m-d", strtotime($_POST['e_date']));
        $select = "SELECT * FROM check_in_out
        WHERE em_id = '$em_id' AND (date BETWEEN '$s_date' AND '$e_date')";
        $query = $this->conn->query($select);
        if ($query->num_rows > 0) {

            foreach ($query as $row) {
                // in_out time
                $c_i = strtotime($row['check_in']);
                $c_o = strtotime($row['check_out']);
                $totaltime_c = ($c_o - $c_i);

                // break time
                $b_i = strtotime($row['break_in']);
                $b_o = strtotime($row['break_out']);
                $totaltime_b = ($b_o - $b_i);

                if ($totaltime_c > 0) {
                    $sum_w += $totaltime_c;
                    $h_c = date("H", $totaltime_c) . "h";
                    $i_c = date("i", $totaltime_c) . "m";
                    $s_c = date("s", $totaltime_c) . "s";
                    $working_hour = $h_c . ":" . $i_c . ":" . $s_c;
                } else {
                    $working_hour = "-";
                }
                if ($totaltime_b > 0) {
                    $sum_b += $totaltime_b;
                    $h_b = date("H", $totaltime_b) . "h";
                    $i_b = date("i", $totaltime_b) . "m";
                    $s_b = date("s", $totaltime_b) . "s";
                    $break_hour = $h_b . ":" . $i_b . ":" . $s_b;
                } else {
                    $break_hour = "-";
                }
                // Total time
                if ($totaltime_c > 0) {
                    $cal = ($totaltime_c - $totaltime_b);
                    $sum_t += $cal;
                } else {
                    $cal = "t";
                }
            ?>
                <tr>
                    <td><?php echo $counter++; ?> </td>
                    <td><?php echo date("d-M-Y", strtotime($row['date'])); ?></td>
                    <td><?php echo $row['check_in']; ?></td>
                    <td><?php echo $row['check_out']; ?></td>
                    <td><?php echo $row['break_in']; ?></td>
                    <td><?php echo $row['break_out']; ?></td>
                    <td><?php echo $working_hour; ?></td>
                    <td><?php echo $break_hour; ?></td>
                    <td><?php echo $this->timeConvert($cal); ?></td>
                </tr>

            <?php
            } ?>
            <th>Total All</th>
            <td>-</td>
            <td>-</td>
            <td>-</td>
            <td>-</td>
            <td>-</td>
            <td><?php echo $this->timeConvert($sum_w); ?></td>
            <td><?php echo $this->timeConvert($sum_b); ?></td>
            <td><?php echo $this->timeConvert($sum_t); ?></td>
            </tr>
            <?php
        } else {
            echo "Records Not Found";
        }
    }
    // Update Data
    public function updateData()
    {
        $em_id = $_SESSION['em_id'];
        $eid = $_SESSION['eid'];
        $name =  $this->conn->real_escape_string($_POST['name']);
        $e_id = $_POST['e_id'];
        $d_id = $_POST['d_id'];
        if ($em_id == null) {
            $this->error['status'] = 0;
            $this->error['message'] = "Id Couldn't Find";
        } else if ($name == null) {
            $this->error['status'] = 0;
            $this->error['message'] = "Please Enter Name";
        } else if ($e_id == null) {
            $this->error['status'] = 0;
            $this->error['message'] = "Please Enter Employee.No ";
        } else if ($d_id == null) {
            $this->error['status'] = 0;
            $this->error['message'] = "Please Enter Designation";
        } else {
            $this->error['status'] = 1;
        }
        if ($this->error['status'] == 1) {
            $update = "UPDATE `employee_register` SET name = '$name', e_id = '$e_id', d_id = '$d_id' WHERE em_id ='$em_id' ";
            $query = $this->conn->query($update);
            if ($query == TRUE) {
                $this->error['status'] = 1;
                $this->error['message'] = "Data Update Successfull";
            } else {
                $this->error['status'] = 0;
                $this->error['message'] = "ERROR :- " . $this->conn->error . "&nbsp;&nbsp;&nbsp;Please use Different Username ";
            }
        } else {
            $this->error['status'] = 0;
            $this->error['message'] = "Data Isn't Updated";
        }
        echo json_encode($this->error);
    }

    // User Entry
    public function empEntry()
    {
        date_default_timezone_set('Asia/Kolkata');
        $e_id = $_POST['e_id'];

        if ($e_id == null) {
            $this->error['status'] = 0;
            $this->error['message'] = "Please Enter Employee.No ";
        } else {
            $this->error['status'] = 1;
        }
        if ($this->error['status'] == 1) {
            $check = "SELECT em_id,e_id FROM employee_register WHERE e_id = '$e_id'";
            $r = $this->conn->query($check);
            if ($r->num_rows == 1) {
                $row = $r->fetch_assoc();
                $id = $row['em_id'];
                $date = date("Y-m-d");
                $check_in = date("H:i:s");
                $insert = "INSERT INTO check_in_out(em_id,date,check_in) VALUES ('$id','$date','$check_in')";

                $query = $this->conn->query($insert);
                if ($query == TRUE) {
                    $this->error['status'] = 1;
                    $this->error['message'] = "Check-in Successfull";
                }
            } else {
                $this->error['status'] = 0;
                $this->error['message'] = 'Please Enter Valid Employee.No';
            }
        } else {
            $this->error['status'] = 0;
            $this->error['message'] = "Please Fill All Details In Form";
        }
        echo json_encode($this->error);
    }
    // User Exit
    public function empExit()
    {
        date_default_timezone_set('Asia/Kolkata');
        $e_id = $_POST['e_id'];
        if ($e_id == null) {
            $this->error['status'] = 0;
            $this->error['message'] = "Please Enter Employee.No ";
        } else {
            $this->error['status'] = 1;
        }
        if ($this->error['status'] == 1) {
            $check = "SELECT em_id,e_id FROM employee_register WHERE e_id = '$e_id'";
            $r = $this->conn->query($check);
            if ($r->num_rows == 1) {
                $row = $r->fetch_assoc();
                $id = $row['em_id'];
                $date = date("Y-m-d");
                $cmp = "SELECT em_id,break_in,break_out,check_out FROM check_in_out WHERE em_id = '$id' AND date = '$date'";
                $result = $this->conn->query($cmp);
                if ($result->num_rows == 1) {
                    $row = $result->fetch_assoc();
                    if ($row['break_out'] == NULL && $row['break_in'] == NULL) {
                        if ($row['check_out'] == NULL) {
                            $check_out = date("H:i:s");
                            $insert = "UPDATE check_in_out SET check_out='$check_out' WHERE em_id = '$id' AND date = '$date'";
                            $query = $this->conn->query($insert);
                            if ($query == TRUE) {
                                $this->error['status'] = 1;
                                $this->error['message'] = "Check-Out Successfull";
                            }
                        } else {
                            $this->error['status'] = 0;
                            $this->error['message'] = "You Already Check-Out ";
                        }                        
                    } else if ($row['break_out'] != NULL) {
                        if ($row['check_out'] == NULL) {
                            $check_out = date("H:i:s");
                            $insert = "UPDATE check_in_out SET check_out='$check_out' WHERE em_id = '$id' AND date = '$date'";
                            $query = $this->conn->query($insert);
                            if ($query == TRUE) {
                                $this->error['status'] = 1;
                                $this->error['message'] = "Check-Out Successfull";
                            }
                        } else {
                            $this->error['status'] = 0;
                            $this->error['message'] = "You Already Check-Out ";
                        }
                    } else {
                        $this->error['status'] = 0;
                        $this->error['message'] = "You Forgot To Break-Out";
                    }
                } else {
                    $this->error['status'] = 0;
                    $this->error['message'] = 'You Forgot To Chek-In';
                }
            } else {
                $this->error['status'] = 0;
                $this->error['message'] = 'Please Enter Valid Employee.No';
            }
        } else {
            $this->error['status'] = 0;
            $this->error['message'] = "Please Fill All Details In Form";
        }
        echo json_encode($this->error);
    }
    // Break-In
    public function empBreakIn()
    {
        date_default_timezone_set('Asia/Kolkata');
        $e_id = $_POST['e_id'];
        if ($e_id == null) {
            $this->error['status'] = 0;
            $this->error['message'] = "Please Enter Employee.No ";
        } else {
            $this->error['status'] = 1;
        }
        if ($this->error['status'] == 1) {
            $check = "SELECT em_id,e_id FROM employee_register WHERE e_id = '$e_id'";
            $result = $this->conn->query($check);
            if ($result->num_rows == 1) {
                $row = $result->fetch_assoc();
                $id = $row['em_id'];
                $date = date("Y-m-d");
                $cmp = "SELECT break_in,em_id,check_out FROM check_in_out WHERE em_id = '$id' AND date = '$date'";
                $result = $this->conn->query($cmp);
                $row_i = $result->fetch_assoc();
                if ($result->num_rows == 1 && $row_i['check_out'] == NULL) {
                    if ($row_i['break_in'] == NULL) {
                        $break_in = date("H:i:s");
                        $insert = "UPDATE check_in_out SET break_in='$break_in' WHERE em_id = '$id' AND date = '$date'";
                        $query = $this->conn->query($insert);
                        if ($query == TRUE) {
                            $this->error['status'] = 1;
                            $this->error['message'] = "Break-In Successfull";
                        }
                    } else {
                        $this->error['status'] = 0;
                        $this->error['message'] = "You Already Break-In ";
                    }
                } else {
                    $this->error['status'] = 0;
                    $this->error['message'] = 'You Forgot To Chek-In';
                }
            } else {
                $this->error['status'] = 0;
                $this->error['message'] = 'Please Enter Valid Employee.No';
            }
        } else {
            $this->error['status'] = 0;
            $this->error['message'] = "Please Fill All Details In Form";
        }
        echo json_encode($this->error);
    }
    // Brea-Out
    public function empBreakOut()
    {
        date_default_timezone_set('Asia/Kolkata');
        $e_id = $_POST['e_id'];
        if ($e_id == null) {
            $this->error['status'] = 0;
            $this->error['message'] = "Please Enter Employee.No ";
        } else {
            $this->error['status'] = 1;
        }
        if ($this->error['status'] == 1) {
            $check = "SELECT em_id,e_id FROM employee_register WHERE e_id = '$e_id'";
            $r = $this->conn->query($check);
            if ($r->num_rows == 1) {
                $row = $r->fetch_assoc();
                $id = $row['em_id'];
                $date = date("Y-m-d");
                $cmp = "SELECT em_id,break_in,break_out FROM check_in_out WHERE em_id = '$id' AND date = '$date'";
                $result = $this->conn->query($cmp);
                $row = $result->fetch_assoc();
                if ($result->num_rows == 1 && $row['break_in'] != NULL) {
                    if ($row['break_out'] == NULL) {
                        $break_out = date("H:i:s");
                        $insert = "UPDATE check_in_out SET break_out='$break_out' WHERE em_id = '$id' AND date = '$date'";
                        $query = $this->conn->query($insert);
                        if ($query == TRUE) {
                            $this->error['status'] = 1;
                            $this->error['message'] = "Break-out Successfull";
                        }
                    } else {
                        $this->error['status'] = 0;
                        $this->error['message'] = "You Already Break-out ";
                    }
                } else {
                    $this->error['status'] = 0;
                    $this->error['message'] = 'You Forgot To Break-In';
                }
            } else {
                $this->error['status'] = 0;
                $this->error['message'] = 'Please Enter Valid Employee.No';
            }
        } else {
            $this->error['status'] = 0;
            $this->error['message'] = "Please Fill All Details In Form";
        }
        echo json_encode($this->error);
    }
    // date
    public function liveSearch()
    {
        $name = $_POST['search'];
        if ($name == null) {
            $this->error['status'] = 0;
            $this->error['message'] = "Please Enter Search ";
        } else {
            $this->error['status'] = 1;
        }
        if ($this->error['status'] == 1) {
            $counter = 1;
            $show = "SELECT e.em_id,e.name,e.e_id,e.d_id,d.title,e.created_on
                FROM `employee_register` AS e
                INNER JOIN `designation` AS d
                ON e.d_id = d.d_id
                WHERE e.name LIKE '$name%'
                ORDER BY e_id  ASC";
            $result = $this->conn->query($show);
            if ($result->num_rows > 0) {
                foreach ($result as $row) {
                    $emid = $row['em_id'];
                    $e_id = $row['e_id'];
            ?>
                    <tr>
                        <td><?php echo $counter++; ?> </td>
                        <td><?php echo $row['e_id']; ?> </td>
                        <td><?php echo stripslashes($row['name']); ?></td>
                        <td><?php echo $row['title']; ?></td>
                        <td><?php echo date("d-M-Y", strtotime($row['created_on'])); ?></td>
                        <td><a id="edit" href="updatepage.php?id=<?php echo base64_encode($emid); ?>">Update</a></td>
                        <td><a id="history" class="history" href="historypage.php?e_id=<?php echo base64_encode($e_id); ?>">History</a></td>
                    </tr>
<?php
                }
                $this->error['status'] = 1;
            } else {
                echo "no";
            }
        }
    }
    // Logout 
    public function logout()
    {
        session_destroy();
    }
}
?>