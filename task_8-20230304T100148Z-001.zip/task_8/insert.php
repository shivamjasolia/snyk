<html>
<head>
    <style>
        img {
            padding: 30px;
            display: block;
            margin-left: auto;
            margin-right: auto;
        }
    </style>
</head>
<body>
    <h1 style="text-align:center;"> Your Record Is Successfully Inserted. </h1>
    <img src="https://res.cloudinary.com/jerrick/image/upload/f_jpg,fl_progressive,q_auto,w_1024/ozysmzeemydbtjwhkjjw.jpg" height="400px">
    <script>
        setTimeout(myFunction,3000);
        function myFunction() {
            window.location.href="adminpanel.php";
        }
    </script>
</body>
</html>