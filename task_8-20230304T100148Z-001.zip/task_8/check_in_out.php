<?php
include "main_api.php";
$obj = new adminLogin();
?>
<!DOCTYPE html>
<html>

<head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="text/css" href="assets\css\entry_exit.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
    <script src="assets\js\main.js"></script>
</head>

<body>
    <!-- Time -->
    <div id="runningTime"></div>

    <form name="myForm" id="emp_attendance" method="post">
        <div class="container">
            <img id="logo" src="https://cdn.impactinit.com/resizenp/600x600/x@7c924f1572/smss53/smsimg28/pv1000/isignstockcontributors/iss_15187_06814.jpg" height="100px">
            <h1 style="text-align:center;">Employee Entry & Exit</h1>
            <p style="text-align:center;">Please fill in this form to login an account.</p>
            <div style="text-align:center;">
                <span class="form-message"></span>
            </div>
            <hr>
            <!-- emp.No -->
            <label for="e_id"><b>Employee.No</b></label>
            <input type="e_id" id="e_id" name="e_id" value="">
            <span class="err" id="err_e_id"></span>
            <br><br><br>
            <button type="button" class="ex-btn" id="entry" name="check-in" style="font-size:20px;">Check-In</button>
            <button type="button" class="ex-btn" id="exit" name="check-out" style="font-size:20px;">Check-Out</button>
            <button type="button" class="br-btn" id="break-in" name="break-in" style="font-size:20px;">Break-In</button>
            <button type="button" class="br-btn" id="break-out" name="break-out" style="font-size:20px;">Break-Out</button>
        </div>

    </form>
</body>

</html>