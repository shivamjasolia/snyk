<?php
include "main_api.php";

if (isset($_SESSION['id'])) {
    header("Location:adminpanel.php");
}
$obj = new adminLogin();
?>
<!DOCTYPE html>
<html>

<head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="text/css" href="assets\css\login.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
    <script src="assets\js\main.js"></script>
</head>

<body>
    <form name="myForm" id="login" method="post">
        <div class="container">
            <img id="logo" src="https://cdn.impactinit.com/resizenp/600x600/x@7c924f1572/smss53/smsimg28/pv1000/isignstockcontributors/iss_15187_06814.jpg" height="100px">
            <h1 style="text-align:center;">Login Form</h1>
            <p style="text-align:center;">Please fill in this form to login an account.</p>
            <div>
                <span class="form-message"></span>
            </div>
            <hr>
            <!-- username -->
            <label for="email"><b>Email</b></label>
            <input type="email" id="email" name="email" value="">
            <span class="err" id="err_email"></span>
            <br><br><br>
            <!-- password -->
            <label for="psw"><b>Password</b></label>
            <input type="password" id="pass" name="pass" value="">
            <span class="err" id="err_pass"></span>
            <br><br>
            <input type="checkbox" onclick="password()">Show Password
            <button type="button" class="login-btn" name="login" style="font-size:20px;">Login</button>
        </div>

    </form>
</body>

</html>