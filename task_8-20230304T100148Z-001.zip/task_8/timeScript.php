<?php
  date_default_timezone_set('Asia/Kolkata');
  echo $runningTime = date('h:i:s A');
?>