<?php
include "main_api.php";
if (!isset($_SESSION['id'])) {
    header("location:login.php");
}
$obj = new adminLogin();
if (isset($_GET['e_id'])) {
    $_SESSION['e_id'] = base64_decode($_GET['e_id']);
    $name = $obj->getName();
    // var_dump($name);
?>
    <html>

    <head>
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
        <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
        <!-- predifined Date range picker -->
        <script type="text/javascript" src="https://cdn.jsdelivr.net/jquery/latest/jquery.min.js"></script>
        <script type="text/javascript" src="https://cdn.jsdelivr.net/momentjs/latest/moment.min.js"></script>
        <script type="text/javascript" src="https://cdn.jsdelivr.net/npm/daterangepicker/daterangepicker.min.js"></script>
        <link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/npm/daterangepicker/daterangepicker.css" />
        <!-- custom css -->
        <link rel="stylesheet" type="text/css" href="assets\css\employeelist.css">
        <!-- custom js -->
        <script src="assets\js\main.js"></script>
    </head>

    <body>
        <a style="float:left;margin:5px;" class="back" href="employeelist.php">Back</a>
        <a class='logout'> Log-Out </a>
        <br><br><br>
        <form class="container">
            <h2>Working History</h2>
            <br>
            <hr>

            Date :<input id="drp" class="datepicker" type="text" name="dates" value="">
            <table>
                <br><br>
                <h3><?php echo "Employee.No :- " . $name['e_id'] . "<br>Employee Name :- " . $name['name'] ?></h3>
                <tr>
                    <th>No</th>
                    <th>Date</th>
                    <th>Check-In</th>
                    <th>Check-Out</th>
                    <th>Break-In</th>
                    <th>Break-Out</th>
                    <th>Working Hours</th>
                    <th>Break Hours</th>
                    <th>Total Time</th>
                </tr>
                <tbody id="response-data">

                </tbody>
            </table>

        </form>
    </body>

    </html>
<?php
} else {
    echo "<h1 style='text-align:center;'>Records Not Found</h1>";
}
?>